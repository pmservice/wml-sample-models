import urllib3, requests, json
from tornado.escape import json_encode, json_decode, url_escape


# Define scoring function
def callModel(payload_scoring):

    print(json.dumps(payload_scoring))
    wml_credentials={"url": "https://wml-fvt.ml.test.cloud.ibm.com", "username": "6d84c35b-37d1-4a38-85f2-2176fe192275", "password": "0386cdab-bf13-4c6a-9767-f457fa65d031"}

    headers = urllib3.util.make_headers(basic_auth='{username}:{password}'.format(username=wml_credentials['username'], password=wml_credentials['password']))
    url = '{}/v3/identity/token'.format(wml_credentials['url'])
    response = requests.get(url, headers=headers)
    mltoken = json.loads(response.text).get('token')

    header = {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + mltoken}

    response_scoring = requests.post('https://wml-fvt.ml.test.cloud.ibm.com/v3/scoring/online/naive_model', json=payload_scoring, headers=header)

    scoring_response = json_decode(response_scoring.text)
    return scoring_response


def score(input):
    
    """AI function example.

    Example:
      {
        "fields": ["GENDER", "AGE", "MARITAL_STATUS", "PROFESSION"],
        "values": [
          ["M", 27, "Single", "Professional"],
          ["F", 56, "Married", "Hospitality"]
        ]
      }
    """
    
    # Score using the pre-defined model 
    prediction = callModel(input);

    return prediction
