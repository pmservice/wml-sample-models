def size():
    return 10

def rank():
    return 0
