#cloned from: https://github.ibm.com/Deep-Learning-Research/TensorFlow-BLC/blob/master/scripts/mnist/blc_mnist_N.py
import tensorflow as tf
import numpy as np

import ctypes

ctypes.CDLL("libmpi.so", mode=ctypes.RTLD_GLOBAL)
############################################################################
#   BLUECONNECT SETUP
############################################################################
 

#no gpu memory preallocation
config = tf.ConfigProto()
config.gpu_options.allow_growth = True 
#config.log_device_placement = True
#load blueconnect lib
blc = tf.load_op_library('ddl_MDR.so') 

#initialize blueconnect
with tf.Session(config=config) as sess: 
    with tf.device('/cpu:0'):
        rank,size,local_rank,local_size,gpuid = sess.run(blc.init(4, mode = '-mode b:2x1 -dump_iter 100 -dbg_level 1'))

        print('* rank: %d, size: %d, local_rank:%d, local_size:%d gpuid: %d, hosts: %d'
            % (rank, size, local_rank, local_size, gpuid, -1))

        
#mpi info and assigned GPU
print([rank,size,gpuid])


#perform all tensorflow computation within gpuid
with tf.device('/gpu:%d' %gpuid):
    ##############################################################################
    # Import MNIST data
    
    from tensorflow.examples.tutorials.mnist import input_data
    mnist = input_data.read_data_sets("/tmp/data"+str(gpuid), one_hot=True)

    # Parameters
    learning_rate = 0.001
    training_iters = 2000
    batch_size = 100
    display_step = 1

    # Network Parameters
    n_input = 784 # MNIST data input (img shape: 28*28)
    n_classes = 10 # MNIST total classes (0-9 digits)
    dropout = 0.75 # Dropout, probability to keep units

    # tf Graph input
    x = tf.placeholder(tf.float32, [None, n_input])
    y = tf.placeholder(tf.float32, [None, n_classes])
    keep_prob = tf.placeholder(tf.float32) #dropout (keep probability)


    # Create some wrappers for simplicity
    def conv2d(x, W, b, strides=1):
        # Conv2D wrapper, with bias and relu activation
        x = tf.nn.conv2d(x, W, strides=[1, strides, strides, 1], padding='SAME')
        x = tf.nn.bias_add(x, b)
        return tf.nn.relu(x)


    def maxpool2d(x, k=2):
        # MaxPool2D wrapper
        return tf.nn.max_pool(x, ksize=[1, k, k, 1], strides=[1, k, k, 1],
                              padding='SAME')


    # Create model
    def conv_net(x, weights, biases, dropout):
        # Reshape input picture
        x = tf.reshape(x, shape=[-1, 28, 28, 1])

        # Convolution Layer
        conv1 = conv2d(x, weights['wc1'], biases['bc1'])
        # Max Pooling (down-sampling)
        conv1 = maxpool2d(conv1, k=2)

        # Convolution Layer
        conv2 = conv2d(conv1, weights['wc2'], biases['bc2'])
        # Max Pooling (down-sampling)
        conv2 = maxpool2d(conv2, k=2)

        # Fully connected layer
        # Reshape conv2 output to fit fully connected layer input
        fc1 = tf.reshape(conv2, [-1, weights['wd1'].get_shape().as_list()[0]])
        fc1 = tf.add(tf.matmul(fc1, weights['wd1']), biases['bd1'])
        fc1 = tf.nn.relu(fc1)
        # Apply Dropout
        fc1 = tf.nn.dropout(fc1, dropout)

        # Output, class prediction
        out = tf.add(tf.matmul(fc1, weights['out']), biases['out'])
        return out

    # We'd like to ensure that all weights and biases are initialized
    # to the exact same values. Since we might be running on multiple
    # GPUs in different Python/TensorFlow processes, the initial values
    # from the MPI root rank will be broadcast to all other workers.
    # Mind though that we must guarantee that the broadcasts are done
    # in a fixed order for each process, hence the need to add explicit
    # dependency edges to the graph to link up the variable nodes in
    # order of creation.

    # 5x5 conv, 1 input, 32 outputs
    init_val = tf.random_normal([5, 5, 1, 32])
    init_val = blc.bcast(init_val)
    wc1 = tf.Variable(init_val)
    bcast_op = init_val

    # 5x5 conv, 32 inputs, 64 outputs
    init_val = tf.random_normal([5, 5, 32, 64])
    with tf.control_dependencies([bcast_op]):
        init_val = blc.bcast(init_val)
    wc2 = tf.Variable(init_val)
    bcast_op = init_val

    # fully connected, 7*7*64 inputs, 1024 outputs
    init_val = tf.random_normal([7*7*64, 1024])
    with tf.control_dependencies([bcast_op]):
        init_val = blc.bcast(init_val)
    wd1 = tf.Variable(init_val)
    bcast_op = init_val

    # 1024 inputs, 10 outputs (class prediction)
    init_val = tf.random_normal([1024, n_classes])
    with tf.control_dependencies([bcast_op]):
        init_val = blc.bcast(init_val)
    out = tf.Variable(init_val)
    bcast_op = init_val

    # Dict of all weights:
    weights = { 'wc1': wc1, 'wc2': wc2, 'wd1': wd1, 'out': out }

    init_val = tf.random_normal([32])
    with tf.control_dependencies([bcast_op]):
        init_val = blc.bcast(init_val)
    bc1 = tf.Variable(init_val)
    bcast_op = init_val

    init_val = tf.random_normal([64])
    with tf.control_dependencies([bcast_op]):
        init_val = blc.bcast(init_val)
    bc2 = tf.Variable(init_val)
    bcast_op = init_val

    init_val = tf.random_normal([1024])
    with tf.control_dependencies([bcast_op]):
        init_val = blc.bcast(init_val)
    bd1 = tf.Variable(init_val)
    bcast_op = init_val

    init_val = tf.random_normal([n_classes])
    with tf.control_dependencies([bcast_op]):
        init_val = blc.bcast(init_val)
    out = tf.Variable(init_val)

    # Dict of all biases:
    biases = { 'bc1': bc1, 'bc2': bc2, 'bd1': bd1, 'out': out }

    # Construct model
    pred = conv_net(x, weights, biases, keep_prob)

    # Define loss and optimizer
    cost = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(logits=pred, labels=y))
    optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate)
    
    
    ############################################################################
    #   BLUECONNECT ALLREDUCE BEGIN
    ############################################################################
    #replace this
    #objective = optimizer.minimize(cost)
    
    grads_and_vars = optimizer.compute_gradients(cost)    
    
    #grads_and_vars_blc = [( blc.all_reduce(gv[0], op='avg', mpi=True), gv[1]) for gv in grads_and_vars]
    
    grads, vars = zip(*grads_and_vars)     
    grads_and_vars_blc = zip(blc.all_reduce_n(grads, op='avg'), vars)
    
    
    #grad_flat = blc.all_reduce_n(
    #   [ grads_and_vars[0][0],
    #    grads_and_vars[1][0],
    #    grads_and_vars[2][0],
    #    grads_and_vars[3][0],
    #    grads_and_vars[4][0],
    #    grads_and_vars[5][0]],
    #    op='avg')
        
    #grad_flat2 = blc.all_reduce_n(
    #   [ 
    #    grads_and_vars[6][0],
    #    grads_and_vars[7][0]],
    #    op='avg')
        
    
    #grads_and_vars_blc = [    
    #    ( grad_flat[0] , grads_and_vars[0][1]),
    #    ( grad_flat[1] , grads_and_vars[1][1]), 
    #    ( grad_flat[2] , grads_and_vars[2][1]),
    #    ( grad_flat[3] , grads_and_vars[3][1]),   
    #    ( grad_flat[4] , grads_and_vars[4][1]),
    #    ( grad_flat[5] , grads_and_vars[5][1]),
    #    ( grad_flat2[0] , grads_and_vars[6][1]),
    #    ( grad_flat2[1] , grads_and_vars[7][1]) ]
    
    objective = optimizer.apply_gradients(grads_and_vars_blc)

    #print(grads_and_vars)

    ############################################################################
    #   BLUECONNECT ALLREDUCE END
    ############################################################################

    
    
    
    # Evaluate model
    correct_pred = tf.equal(tf.argmax(pred, 1), tf.argmax(y, 1))
    accuracy = tf.reduce_mean(tf.cast(correct_pred, tf.float32))
    ##############################################################################
    
    
def split(a, n):
    k, m = divmod(len(a), n)
    return (a[i * k + min(i, m):(i + 1) * k + min(i + 1, m)] for i in xrange(n))
    
# Launch the graph
with tf.Session(config=config) as sess:
    sess.run(tf.global_variables_initializer())
    step = 1
    # Keep training until reach max iterations
    while step * batch_size < training_iters:
        batch_x, batch_y = mnist.train.next_batch(batch_size*size)

        batch_x = np.split(batch_x,size)[rank]
        batch_y = np.split(batch_y,size)[rank]
        
        # Run optimization op (backprop)
        sess.run(objective, feed_dict={x: batch_x, y: batch_y,
                                       keep_prob: dropout})
        if step % display_step == 0:
            # Calculate batch loss and accuracy
            loss, acc = sess.run([cost, accuracy], feed_dict={x: batch_x,
                                                              y: batch_y,
                                                              keep_prob: 1.})
            print("MPI "+str(rank)+"] Iter " + str(step*batch_size) + ", Minibatch Loss= " + \
                  "{:.6f}".format(loss) + ", Training Accuracy= " + \
                  "{:.5f}".format(acc))
        step += 1
    print("MPI "+str(rank)+"] Optimization Finished!")

    # Calculate accuracy for 256 mnist test images
    print("MPI "+str(rank)+"] Testing Accuracy:", \
        sess.run(accuracy, feed_dict={x: mnist.test.images[:256],
                                      y: mnist.test.labels[:256],
                                      keep_prob: 1.}))
