var g_mouse_is_down = false;
var g_prev_pixel_X  = -1;
var g_prev_pixel_Y  = -1;
var g_min_X = 200;
var g_min_Y = 200;
var g_max_X = 0;
var g_max_Y = 0;
var g_line_width = 25;


function start_drawing(e)
{
    g_mouse_is_down = true;
    g_prev_pixel_X = e.clientX - document.getElementById( 'drawing_box' ).getBoundingClientRect().left;
    g_prev_pixel_Y = e.clientY - document.getElementById( 'drawing_box' ).getBoundingClientRect().top;
}


function stop_drawing(e)
{
    g_mouse_is_down = false;
}


function draw_line(e)
{
    if( ( g_mouse_is_down ) && ( g_prev_pixel_X > -1 ) && ( g_prev_pixel_Y > -1 ) )
    {
        pixel_X = e.clientX - document.getElementById( 'drawing_box' ).getBoundingClientRect().left;
        pixel_Y = e.clientY - document.getElementById( 'drawing_box' ).getBoundingClientRect().top;
        
        var ctx = document.getElementById( 'drawing_box' ).getContext( '2d' );
        ctx.strokeStyle = "purple";
        ctx.beginPath();
        ctx.moveTo( g_prev_pixel_X, g_prev_pixel_Y );
        ctx.lineTo( pixel_X, pixel_Y );
        ctx.lineWidth = g_line_width;
        ctx.stroke();
        
        g_prev_pixel_X = pixel_X;
        g_prev_pixel_Y = pixel_Y;

        if( pixel_X < g_min_X )
        {
            g_min_X = pixel_X;
        }
        if( pixel_X > g_max_X )
        {
            g_max_X = pixel_X;
        }
        if( pixel_Y < g_min_Y )
        {
            g_min_Y = pixel_Y;
        }
        if( pixel_Y > g_max_Y )
        {
            g_max_Y = pixel_Y;
        }
    }
}


function clear_everything()
{
    var canvas = document.getElementById( 'drawing_box' );
    var ctx = canvas.getContext( '2d' );
    ctx.clearRect( 0, 0, canvas.width, canvas.height );
    
    g_mouse_is_down = false;
    g_prev_pixel_X  = -1;
    g_prev_pixel_Y  = -1;
    g_min_X = 200;
    g_min_Y = 200;
    g_max_X = 0;
    g_max_Y = 0;

    
    document.getElementById( 'model_results_pre' ).innerHTML = "";
    document.getElementById( 'model_results_spinner' ).style.display = "none";
}


function submit_drawing()
{
    smaller_img = get_bounding_box();
    
    setTimeout( function()
    {
        [ centered_img, box_X, box_Y ] = center( smaller_img );
alert( JSON.stringify( centered_img.height, null, 3 ) );
        sendPayloadToModel( centered_img );

    }, 1000 );
}


function get_bounding_box()
{
    min_X  = g_min_X - g_line_width/2;
    min_Y  = g_min_Y - g_line_width/2;
    width  = g_max_X - g_min_X + g_line_width;
    height = g_max_Y - g_min_Y + g_line_width;
    
    var ctx = document.getElementById( 'drawing_box' ).getContext( '2d' );
    var smaller_image = ctx.getImageData( min_X, min_Y, width, height );

    // Show what's going on
    ctx.strokeStyle = "red";
    ctx.lineWidth = 2;
    ctx.rect( min_X, min_Y, width, height );
    ctx.stroke();
    
    return smaller_image;
}


function center( img )
{
    var canvas = document.getElementById( 'drawing_box' );
    var img_X = canvas.width/2  - img.width/2;
    var img_Y = canvas.height/2 - img.height/2;

    var max_dimension = ( img.height > img.width ) ? img.height : img.width;

    var box_X = canvas.width/2  - max_dimension/2;
    var box_Y = canvas.height/2 - max_dimension/2;
    
    // Show what's going on
    var ctx = canvas.getContext( '2d' );
    ctx.clearRect( 0, 0, canvas.width, canvas.height );
    ctx.beginPath();
    ctx.putImageData( img, img_X, img_Y );
    ctx.strokeStyle = "red";
    ctx.lineWidth = 2;
    ctx.rect( box_X - 2, box_Y - 2, max_dimension + 4, max_dimension + 4 );
    ctx.stroke();
    centered_img = ctx.getImageData( box_X, box_Y, max_dimension, max_dimension );
    
    return [ centered_img, box_X, box_Y ];
}


function sendPayloadToModel( img )
{
    document.getElementById( 'model_results_spinner' ).style.display = 'block';
//JSON.stringify( { "img_data" : Array.from( img.data ) } ),
    $.ajax( { method      : "POST",
              url         : "./identifydigit",
              contentType : "application/json",
              data        : JSON.stringify( { "height": img.height, "data" : Array.from( img.data ) } ),
              dataType    : "json",
              success     : function( result )
                            {
                                document.getElementById( 'model_results_spinner' ).style.display = 'none';
                                
                                if( "values" in result )
                                {
                                    if( result.values.length > 0 )
                                    {
                                        document.getElementById( 'model_results_pre' ).innerHTML = result.values[0];
                                    }
                                    else
                                    {
                                        document.getElementById( 'model_results_pre' ).innerHTML = "No data returned.";
                                    }
                                }
                                else
                                {
                                    alert( JSON.stringify( result, null, 3 ) )
                                }
                            }
            } );

}

