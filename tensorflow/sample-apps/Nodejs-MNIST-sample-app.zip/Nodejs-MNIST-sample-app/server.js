/*
 * 1.  Fill in wml_credentials.
 *
 */
var wml_credentials = {
    "instance_id": "",
    "password": "",
    "url": "",
    "username": ""
};

/*
 * 2.  Fill in one or both of these:
 *     - model_deployment_endpoint_url
 *     - function_deployment_endpoint_url
 */
var model_deployment_endpoint_url    = "";
var function_deployment_endpoint_url = "";


// Express - needed to host this app on IBM Cloud ...
var express = require( 'express' );
var app     = express();
app.use( express.static( __dirname + '/public' ) );


// Cloud Foundry - needed to push/host our app on IBM Cloud ...
var cfenv  = require( 'cfenv' );
var appEnv = cfenv.getAppEnv();
var server = app.listen( appEnv.port, appEnv.bind, function()
{
    console.log( 'Server starting on ' + appEnv.url );

} );


var io = require( 'socket.io' )( server );
io.on( 'connection', function( socket )
{
	console.log( 'io: connection...' );

	socket.on( 'sendtomodel', function( data )
	{
		console.log( 'io: sendtomodel...' );

        processdata( model_deployment_endpoint_url, data ).then( function( result )
        {
            console.log( "Result:\n" + JSON.stringify( result, null, 3 ) );
            socket.emit( 'processresult', result );

        } ).catch( function( error )
        {
            console.log( "Error:\n" + error );
            socket.emit( 'processresult', { "error" : error } );

        } );

	} );

	socket.on( 'sendtofunction', function( data )
	{
		console.log( 'io: sendtofunction...' );

        processdata( function_deployment_endpoint_url, data ).then( function( result )
        {
            console.log( "Result:\n" + JSON.stringify( result, null, 3 ) );
            socket.emit( 'processresult', result );

        } ).catch( function( error )
        {
            console.log( "Error:\n" + error );
            socket.emit( 'processresult', { "error" : error } );

        } );

	} );

} );


function processdata( endpoint_url, payload )
{
    return new Promise( function( resolve, reject )
    {
        if( "" == endpoint_url )
        {
            reject( "Endpoint URL not set in 'server.js'" );
        }
        else
        {
            getAuthToken( wml_credentials["url"], wml_credentials["username"], wml_credentials["password"] ).then( function( token )
            {
                sendtodeployment( endpoint_url, token, payload ).then( function( result )
                {
                    resolve( result );

                } ).catch( function( processing_error )
                {
                    reject( "Send to deployment error:\n" + processing_error );

                } );

            } ).catch( function( token_error )
            {
                reject( "Generate token:\n" + token_error );

            } );
        }

    } );    

}


function getAuthToken( url, username, password )
{
    // Use the IBM Watson Machine Learning REST API to get an access token
    // https://watson-ml-api.mybluemix.net/
    //
    return new Promise( function( resolve, reject )
    {
        var btoa = require( 'btoa' );
        var options = { url     : url + '/v3/identity/token',
                        headers : { 'Authorization' : 'Basic ' + btoa( username + ":" + password ) } };

        var request = require( 'request' );
        request.get( options, function( error, response, body )
        {
            if( error )
            {
                reject( error );
            }
            else
            {
                try
                {
                    resolve( JSON.parse( body ).token );
                }
                catch( e )
                {
                    reject( 'JSON.parse failed.' );
                }
            }

        } );

    } );    

}


function sendtodeployment( endpoint_url, token, payload )
{
    // Use the IBM Watson Machine Learning REST API to send the payload to the deployment
    // https://watson-ml-api.mybluemix.net/
    //
    return new Promise( function( resolve, reject )
    {
        var options = { url     : endpoint_url,
                        headers : { 'Authorization' : 'Bearer ' + token, 'Content-type'  : 'application/json' },
                        body    : JSON.stringify( payload ) };

        var request = require( 'request' );
        request.post( options, function( error, response, body )
        {
            if( error )
            {
                reject( error );
            }
            else
            {
                try
                {
                    resolve( JSON.parse( body ) );
                }
                catch( e )
                {
                    reject( 'JSON.parse failed.' );
                }
            }

        } );

    } );

}


